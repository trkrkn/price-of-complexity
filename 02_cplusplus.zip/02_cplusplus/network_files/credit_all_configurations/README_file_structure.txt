the network files are as follows:
each line represents lending activity of each agent 
(line 0 = ... ... ...) = list of agets agent 0 is lending to
the list consists of identifiers separated via tabs.
